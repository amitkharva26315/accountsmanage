<template>
  <header class="header">
    <h3>To Do Lists</h3>
    <div id="nav">
      <router-link to="/">Home</router-link>|
      <router-link to="/about">About</router-link>
    </div>
  </header>
</template>

<script>
export default {
  name: "Header"
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.header{
  background:#333;
  color:#fff;
  text-align: center;
  padding:10px;
}

.header a{
  /* color:#fff !important; */
  padding-right:5px;
  text-decoration:none;
}
</style>
