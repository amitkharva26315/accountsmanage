<template>
  <p>invoice page</p>
</template>

<script>
export default {

}
</script>

<style>

</style>