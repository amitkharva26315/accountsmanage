<template>
  <p>items services page</p>
</template>

<script>
export default {

}
</script>

<style>

</style>